<?php
if ( ! defined( 'ABSPATH' ) ) exit;


// scilent is gold
 ?>